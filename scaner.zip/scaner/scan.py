import nmap
import time
import sys
import argparse
import concurrent.futures
import ipaddress
import json
from termcolor import colored
import os
import colorama
from colorama import Fore, Back, Style

colorama.init(autoreset=True)

def print_title():
    print(Fore.CYAN + Style.BRIGHT + """
 ____        _     ____                ____                                 
/ ___| _   _| |__ |___ \  ____  ___   / ___|  ___ __ _ _ __  _ __   ___ _ __ 
\___ \| | | | '_ \  __) |/ ___|/ _ \  \___ \ / __/ _` | '_ \| '_ \ / _ \ '__|
 ___) | |_| | |_) |/ __/| |   | (_) |  ___) | (_| (_| | | | | | | |  __/ |   
|____/ \__,_|_.__/|_____|_|    \___/  |____/ \___\__,_|_| |_|_| |_|\___|_|   
    """)

def print_dragons_and_firewall():
    print(Fore.BLUE + """
      /\\                """ + Fore.WHITE + """|||| """ + Fore.RED + """               /\\
     /  \\               """ + Fore.WHITE + """|||| """ + Fore.RED + """              /  \\
    /    \\  """ + Fore.CYAN + """_____""" + Fore.BLUE + """     """ + Fore.WHITE + """|||| """ + Fore.RED + """    """ + Fore.YELLOW + """_____""" + Fore.RED + """    /    \\
   /      \\""" + Fore.CYAN + """/     \\""" + Fore.BLUE + """    """ + Fore.WHITE + """|||| """ + Fore.RED + """   """ + Fore.YELLOW + """/     \\""" + Fore.RED + """  /      \\
  /   /\\   """ + Fore.CYAN + """\\     /""" + Fore.BLUE + """    """ + Fore.WHITE + """|||| """ + Fore.RED + """   """ + Fore.YELLOW + """\\     /""" + Fore.RED + """ /   /\\   \\
 /   /  \\   """ + Fore.CYAN + """\___/""" + Fore.BLUE + """     """ + Fore.WHITE + """|||| """ + Fore.RED + """    """ + Fore.YELLOW + """\___/""" + Fore.RED + """ /   /  \\   \\
/___/    \\           """ + Fore.WHITE + """|||| """ + Fore.RED + """           /___/    \\
    \\    \\          """ + Fore.WHITE + """|||| """ + Fore.RED + """          /    /
     \\    \\         """ + Fore.WHITE + """|||| """ + Fore.RED + """         /    /
      \\    \\        """ + Fore.WHITE + """|||| """ + Fore.RED + """        /    /
       \\    \\       """ + Fore.WHITE + """|||| """ + Fore.RED + """       /    /
        \\    \\      """ + Fore.WHITE + """|||| """ + Fore.RED + """      /    /
         \\    \\     """ + Fore.WHITE + """|||| """ + Fore.RED + """     /    /
          \\    \\    """ + Fore.WHITE + """|||| """ + Fore.RED + """    /    /
           \\    \\   """ + Fore.WHITE + """|||| """ + Fore.RED + """   /    /
            \\    \\  """ + Fore.WHITE + """|||| """ + Fore.RED + """  /    /
             \\    \\ """ + Fore.WHITE + """|||| """ + Fore.RED + """ /    /
              \\    \\""" + Fore.WHITE + """||||""" + Fore.RED + """/    /
               \\    """ + Fore.WHITE + """||||""" + Fore.RED + """    /
                \\   """ + Fore.WHITE + """||||""" + Fore.RED + """   /
                 \\  """ + Fore.WHITE + """||||""" + Fore.RED + """  /
                  \\ """ + Fore.WHITE + """||||""" + Fore.RED + """ /
                   \\""" + Fore.WHITE + """||||""" + Fore.RED + """/
                    """ + Fore.WHITE + """||||
                    ||||
                    ||||
                    ||||
    """)

print_title()
print_dragons_and_firewall()
print("# Developed by Lawrence Agaga")
print("© 2024 Lawrence Richard Agaga. All rights reserved.")

def check_root():
    if os.geteuid() != 0:
        print(colored("This script requires root privileges. Please run as root or use sudo.", "red"))
        sys.exit(1)

def scan_target(ip_address, scan_type='basic', output_format='text'):
    check_root()  # Check for root privileges
    
    nm = nmap.PortScanner()
    
    scan_types = {
        'basic': '-sS -T4 --randomize-hosts',
        'full': '-sS -sU -T4 -A -v --randomize-hosts',
        'vuln': '-sS -T4 --randomize-hosts --script vuln'
    }
    
    scan_arguments = scan_types.get(scan_type, scan_types['basic'])
    
    print(colored(f"Starting {scan_type} scan on {ip_address}...", "yellow"))
    
    try:
        nm.scan(hosts=ip_address, arguments=scan_arguments)
        print(colored("Scan completed.\n", "green"))
        
        results = {"hosts": []}
        
        for host in nm.all_hosts():
            host_info = {
                "ip": host,
                "hostname": nm[host].hostname(),
                "state": nm[host].state(),
                "protocols": {}
            }
            
            for protocol in nm[host].all_protocols():
                host_info["protocols"][protocol] = []
                ports = nm[host][protocol].keys()
                for port in ports:
                    port_info = {
                        "port": port,
                        "state": nm[host][protocol][port]['state'],
                        "service": nm[host][protocol][port].get('name', '')
                    }
                    host_info["protocols"][protocol].append(port_info)
            
            if 'script' in nm[host]:
                host_info["vulnerabilities"] = nm[host]['script']
            
            results["hosts"].append(host_info)
        
        if output_format == 'json':
            print(json.dumps(results, indent=2))
        else:
            for host in results["hosts"]:
                print(colored(f"Host: {host['ip']} ({host['hostname']})", "cyan"))
                print(colored(f"State: {host['state']}", "cyan"))
                for protocol, ports in host["protocols"].items():
                    print(colored(f"Protocol: {protocol}", "magenta"))
                    for port in ports:
                        print(colored(f"Port: {port['port']}\tState: {port['state']}\tService: {port['service']}", "white"))
                
                if "vulnerabilities" in host:
                    print(colored("Vulnerabilities:", "red"))
                    for script, output in host["vulnerabilities"].items():
                        print(f"{script}:\n{output}\n")
                print("\n")
        
    except Exception as e:
        print(colored(f"Error: {e}", "red"))

def scan_network(network, scan_type='basic', output_format='text', max_workers=10):
    ip_network = ipaddress.ip_network(network)
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(scan_target, str(ip), scan_type, output_format) for ip in ip_network.hosts()]
        concurrent.futures.wait(futures)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Advanced Network Scanner")
    parser.add_argument("target", help="IP address, range (e.g., 192.168.1.1-10), or CIDR notation (e.g., 192.168.1.0/24)")
    parser.add_argument("-t", "--type", choices=['basic', 'full', 'vuln'], default='basic', help="Scan type")
    parser.add_argument("-o", "--output", choices=['text', 'json'], default='text', help="Output format")
    parser.add_argument("-w", "--workers", type=int, default=10, help="Number of concurrent workers")
    args = parser.parse_args()

    try:
        if '/' in args.target:  # CIDR notation
            scan_network(args.target, args.type, args.output, args.workers)
        elif '-' in args.target:  # IP range
            start_ip, end_ip = args.target.split('-')
            start_ip = ipaddress.IPv4Address(start_ip.strip())
            end_ip = ipaddress.IPv4Address(end_ip.strip())
            ip_range = [str(ipaddress.IPv4Address(ip)) for ip in range(int(start_ip), int(end_ip) + 1)]
            for ip in ip_range:
                scan_target(ip, args.type, args.output)
        else:  # Single IP
            scan_target(args.target, args.type, args.output)
    except ValueError as e:
        print(colored(f"Invalid input: {e}", "red"))
        sys.exit(1)

    print(colored("Scan completed.", "green"))
